# import csv
#
# input_file = 'Mesh_ID.csv'
# output_file = 'dislist.csv'  # 新的输出文件名
#
# # 用于存储第一列数据的列表
# first_column_data = []
#
# # 打开文件时指定UTF-8编码
# with open(input_file, 'r', newline='', encoding='utf-8') as csvfile:
#     reader = csv.reader(csvfile)
#     for row in reader:
#         if row:  # 确保不读取空行
#             first_column_data.append(row[0])
#
# # 将第一列数据写入输出文件
# with open(output_file, 'w', encoding='utf-8') as outputfile:
#     for item in first_column_data:
#         outputfile.write(item + '\n')  # 写入数据并添加换行符
#
# # 输出第一列数据
# for item in first_column_data:
#     print(item)
#
# print(f"数据已保存到 {output_file}")
from dataset import train_list,val_list
# import csv
# import openpyxl
#
# # 打开CSV文件
# with open('dislist.csv', 'r', encoding='utf-8') as file:
#     # 创建CSV读取器
#     csv_reader = csv.reader(file)
#
#     # 逐行读取CSV文件内容并只保留每个单元格中的第一个项目
#     data = [[item.strip()] for row in csv_reader for item in row[0].split(',')]
#
# # 创建一个新的工作簿和工作表
# workbook = openpyxl.Workbook()
# worksheet = workbook.active
#
# # 将数据写入工作表
# for row in data:
#     worksheet.append(row)
#
# # 保存工作簿为XLSX文件
# workbook.save('DisName.xlsx')


from model import Model

import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn.functional as F
from torch_geometric.loader import LinkNeighborLoader
from sklearn.metrics import roc_auc_score,classification_report,precision_recall_curve,average_precision_score
from sklearn.metrics import accuracy_score,recall_score,precision_score,f1_score
from sklearn.metrics import roc_curve, precision_recall_curve, roc_auc_score, average_precision_score,classification_report
import torch.nn as nn
#可重复性，固定seed
from torch_geometric import seed_everything
import torch
from torch import Tensor
import torch.nn.functional as F
from torch_geometric.data import HeteroData
from torch_geometric.nn import SAGEConv, GATConv,GATv2Conv,GCNConv, to_hetero
from dataset import data
import pandas as pd
import numpy as np
import torch
from torch_geometric.data import HeteroData
import torch_geometric.transforms as T
import os
from utils import KfoldLinkSplit
#可重复性，固定seed
from torch_geometric import seed_everything

seed_everything(204)
torch.manual_seed(204)
np.random.seed(204)

# 检查是否能使用gpu，如果能使用device=cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)
plt.rcParams['figure.dpi'] = 300

#添加文件夹
folder_list = ['loss','model','roc']
for folder_name in folder_list:
    if (not os.path.exists(folder_name)):
        os.makedirs(folder_name)

#读取特征和关联矩阵
df_diease = pd.read_csv('data/dieaseSmi2.csv',header=None)
df_gene = pd.read_csv('data/geneSim2.csv',header=None)
df_met = pd.read_csv('data/metSim2.csv',header=None)

df_associations_dis_met = pd.read_csv('data/dis_met_mat.csv',header=None)
df_associations_met_gene = pd.read_csv('data/met_gene_mat.csv',header=None)
df_associations_dis_gene = pd.read_csv('data/dis_gene_mat.csv',header=None)

#读取表格数据，转换成numpy，并且标准化
def standarize(df):
    df = df.values
    df_max = df.max()
    df_min = df.min()
    return (df - df_min)/(df_max - df_min)


data = HeteroData()
# 添加节点index
data["diease"].node_id = torch.arange(len(df_diease))
data["gene"].node_id = torch.arange(len(df_gene))
data["met"].node_id = torch.arange(len(df_met))
# 添加节点数据
data["diease"].x = torch.Tensor(standarize(df_diease))
data["gene"].x = torch.Tensor(standarize(df_gene))
data["met"].x = torch.Tensor(standarize(df_met))
# 添加边
associations_indices_dis_met = np.where(df_associations_dis_met.values == 1)
associations_indices_met_gene = np.where(df_associations_met_gene.values == 1)
associations_indices_dis_gene = np.where(df_associations_dis_gene.values == 1)
associations_indices_dis = np.where(df_diease.values > 0 )
associations_indices_gene = np.where(df_gene.values > 0)
associations_indices_met = np.where(df_met.values > 0)
data["diease", "association1", "met"].edge_index = torch.Tensor(associations_indices_dis_met).long()
data["met", "association2", "gene"].edge_index = torch.Tensor(associations_indices_met_gene).long()
data["diease", "association3", "gene"].edge_index = torch.Tensor(associations_indices_dis_gene).long()
data["diease", "association4", "diease"].edge_index = torch.Tensor(associations_indices_dis).long()
data["gene", "association5", "gene"].edge_index = torch.Tensor(associations_indices_gene).long()
data["met", "association6", "met"].edge_index = torch.Tensor(associations_indices_gene).long()
# 使用ToUndirected添加反向的边
data = T.ToUndirected()(data)
print(data)

# 划分数据集,5折
# 随机打乱序号
num_of_links = data["diease", "association1", "met"].edge_index.shape[1]
perm = torch.randperm(num_of_links).tolist()
# 确定折数
num_of_fold = 5
fold_size = int(num_of_links / num_of_fold)
train_list = []
val_list = []

for i in range(num_of_fold):
    transform = KfoldLinkSplit(
        num_val=0.2,  # 训练集20%
        num_test=0.0,
        disjoint_train_ratio=0.3,
        neg_sampling_ratio=100.0,  # 采样负样本边
        add_negative_train_samples=False,
        edge_types=("diease", "association1", "met"),
        rev_edge_types=("met", "rev_association1", "diease"),
        perm=perm  # 固定每一次随机的顺序
    )
    train_data, val_data, _ = transform(data)
    train_list.append(train_data)
    val_list.append(val_data)
    # fold向右滑动一步，依次轮换后20%
    perm_tmp = perm.copy()
    perm = perm_tmp[(num_of_fold - 1) * fold_size:] + perm_tmp[:(num_of_fold - 1) * fold_size]

class GNN(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        #self.conv1 = GATv2Conv(hidden_channels, hidden_channels, head=8, add_self_loops=False)
        #self.conv2 = GATv2Conv(hidden_channels, hidden_channels,head=8,add_self_loops=False)
        self.conv1 = SAGEConv(hidden_channels, hidden_channels)
        self.conv2 = SAGEConv(hidden_channels, hidden_channels)

    def forward(self, x: Tensor, edge_index: Tensor) -> Tensor:
        x = F.relu(self.conv1(x, edge_index))
        x = self.conv2(x, edge_index)
        return x

class Classifier(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        self.att = torch.nn.MultiheadAttention(hidden_channels, 1, batch_first=True)
        self.fc1 = torch.nn.Linear(hidden_channels * 2, 1024)
        self.fc2 = torch.nn.Linear(1024, 1)

    def forward(self, x_diease: Tensor, x_met: Tensor, edge_label_index: Tensor, x_diease_skip: Tensor,
                x_met_skip: Tensor) -> Tensor:
        # 读取4组特征，带skip的是不经过GNN处理的。
        edge_feat_diease = x_diease[edge_label_index[0]]
        edge_feat_met = x_met[edge_label_index[1]]
        edge_feat_diease_skip = x_diease_skip[edge_label_index[0]]
        edge_feat_met_skip = x_met_skip[edge_label_index[1]]
        # 拼接到一起
        feat_cat = torch.cat((edge_feat_diease, edge_feat_met, edge_feat_diease_skip, edge_feat_met_skip), dim=1)
        # self attention
        feat_cat_att, _ = self.att(feat_cat, feat_cat, feat_cat)
        # 将处理前后的特征拼接到一起
        feat_cat = torch.cat((feat_cat, feat_cat_att), dim=1)
        # 全连接
        feat_cat = F.relu(self.fc1(feat_cat))
        feat_cat = self.fc2(feat_cat)
        return feat_cat.squeeze()

class Model(torch.nn.Module):
    def __init__(self, hidden_channels):
        super().__init__()
        #输入层
        self.gene_lin = torch.nn.Linear(data["gene"].num_nodes, hidden_channels)
        self.diease_lin = torch.nn.Linear(data["diease"].num_nodes, hidden_channels)
        self.met_lin = torch.nn.Linear(data["met"].num_nodes, hidden_channels)
        # 实例化GNN
        self.gnn = GNN(hidden_channels)
        # GNN异质图
        self.gnn = to_hetero(self.gnn, metadata=data.metadata())
        # 分类器
        self.classifier = Classifier(hidden_channels * 2 * 2)

    def forward(self, data: HeteroData) -> Tensor:
        x_dict = {
            "met": self.met_lin(data["met"].x),
            "diease": self.diease_lin(data["diease"].x),
            "gene": self.gene_lin(data["gene"].x),
        }
        # `x_dict` 所有节点的特征矩阵
        # `edge_index_dict` 所有边的index
        x_dict_new = self.gnn(x_dict, data.edge_index_dict)
        pred = self.classifier(
            x_dict_new["diease"],
            x_dict_new["met"],
            data["diease", "association1", "met"].edge_label_index,
            x_dict["diease"],
            x_dict["met"],
        )
        return pred

# 验证
def eval_loop(val_loader, fold=0, device='cpu'):
    model = Model(hidden_channels=128).to(device)
    model.load_state_dict(torch.load(f'./model/best_model_{fold}.pth'))
    model.eval()
    preds = []
    ground_truths = []
    for sampled_data in val_loader:
        with torch.no_grad():
            sampled_data.to(device)
            preds.append(model(sampled_data))
            ground_truths.append(sampled_data["diease", "association1", "met"].edge_label)
    pred = torch.cat(preds, dim=0)
    pred = F.sigmoid(pred).cpu().numpy()
    ground_truth = torch.cat(ground_truths, dim=0).cpu().numpy()
    pred_return = pred.copy()
    ground_truth_return = ground_truth.copy()
    auc = roc_auc_score(ground_truth, pred)
    fpr, tpr, thresholds = roc_curve(ground_truth, pred)
    # plt.plot(fpr, tpr, label=f'fold {fold}')
    # plt.legend()
    # plt.xlabel('False positive rate')
    # plt.ylabel('True positive rate')
    # plt.savefig(f'./roc/ROC curve fold {fold}')
    pred = (pred >= 0.5).astype(np.int64)
    print(f"Validation AUC of fold {fold}: {auc:.4f}")
    print(classification_report(ground_truth, pred, zero_division=0.0))
    return pred_return, ground_truth_return, auc

# 预测
i = 0
edge_label_index = val_list[i]["diease", "association1", "met"].edge_label_index
edge_label = val_list[i]["diease", "association1", "met"].edge_label
val_loader = LinkNeighborLoader(
    data=val_list[i],
    num_neighbors=[20, 10],
    edge_label_index=(["diease", "association1", "met"], edge_label_index),
    edge_label=edge_label,
    batch_size=128,
    shuffle=False,
)
    # auc_list.append(eval_loop(val_loader, fold=i, device=device))
p, g, a = eval_loop(val_loader, fold=i, device=device)
edge_label_index = edge_label_index.detach().cpu().numpy()

dieasename = pd.read_csv('dislist.csv',sep='\t')['疾病']
metname = pd.read_csv('metlist.csv')['代谢物ID']
save_list = []
for i in range(len(p)):
    didx = edge_label_index[0,i]
    ridx = edge_label_index[1,i]
    save_list.append([dieasename[didx],metname[ridx],p[i],g[i]])
pd.DataFrame(save_list,columns=['Diease', 'met', 'pred scores', 'ground truth']).to_csv('case.csv')

# 读取CSV文件
csv_file = "case.csv"
df = pd.read_csv(csv_file)

# 将数据写入XLSX文件
xlsx_file = "case.xlsx"
df.to_excel(xlsx_file, index=False)

print(f"{csv_file} 已成功转换为 {xlsx_file}")