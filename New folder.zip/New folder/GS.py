# import numpy as np
# import openpyxl
# import pandas as pd
#
# # 使用高斯核计算相似性
# def gaussian_similarity(x, y, sigma=1.0):
#     return np.exp(-np.linalg.norm(x - y) ** 2 / (2 * sigma ** 2))
#
#
# def complete_similarity_matrix(similarity_matrix):
#     num_diseases = similarity_matrix.shape[0]
#     completed_matrix = np.zeros((num_diseases, num_diseases))
#
#     # 使用高斯核相似性来补全相似性矩阵
#     for i in range(num_diseases):
#         for j in range(num_diseases):
#             if i == j:
#                 completed_matrix[i, j] = 1.0  # 对角线上的相似性为1
#             else:
#                 completed_matrix[i, j] = gaussian_similarity(similarity_matrix[i], similarity_matrix[j])
#
#     return completed_matrix
#
# # def fill_matrix(mat1,mat2):
# #     rows = mat1.shape[0]
# #     cols = mat1.shape[1]
# #     #复制一份防止修改原文件
# #     mat1_copy = mat1.copy()
# #     for i in range(rows):
# #         for j in range(cols):
# #             if mat1[i][j] == 0.0:
# #                 #mat1_copy[i][j] = mat2[i][j]a'na
# #                 mat1_copy.loc[i, j] = mat2[i][j]
# #     return mat1_copy
# def fill_matrix(mat1, mat2):
#     mat1_copy = mat1.copy()
#     for i in range(mat1.shape[0]):
#         for j in range(mat1.shape[1]):
#             mat1_copy.at[i, j] = mat2[i][j]
#     return mat1_copy
#
# # 主程序
# if __name__ == "__main__":
#     # 从本地文件读取疾病语义相似性数据
#     similarity_matrix = pd.read_csv(r'F:\daixie\New folder\data\dis_met_mat.csv',header=None)
#     DMS = np.load(r'F:\daixie\New folder\DMS.npy')
#     print(similarity_matrix.shape)
#     # 补全相似性矩阵
#     completed_matrix = complete_similarity_matrix(similarity_matrix)
#
#     # 保存补全后的相似性矩阵到 Excel 文件
#     excel_file_path = r'F:\daixie\New folder\GS_DMS.xlsx'
#     workbook = openpyxl.Workbook()
#     sheet = workbook.active
#
#     for row in completed_matrix:
#         sheet.append(row.tolist())
#
#     workbook.save(excel_file_path)
#
#     print("Completed Similarity Matrix saved to Excel file:", excel_file_path)
#
#     dms_completed = fill_matrix(DMS, similarity_matrix)
#     excel_file_path = r'F:\daixie\New folder\GS_DMS1.xlsx'
# import numpy as np
# import openpyxl
# import pandas as pd
#
#
# # 使用高斯核计算相似性
# def gaussian_similarity(x, y, sigma=1.0):
#     return np.exp(-np.linalg.norm(x - y) ** 2 / (2 * sigma ** 2))
#
#
# def complete_similarity_matrix(similarity_matrix):
#     num_diseases = similarity_matrix.shape[0]
#     completed_matrix = np.zeros((num_diseases, num_diseases))
#
#     # 使用高斯核相似性来补全相似性矩阵
#     for i in range(num_diseases):
#         for j in range(num_diseases):
#             if i == j:
#                 completed_matrix[i, j] = 1.0  # 对角线上的相似性为1
#             else:
#                 completed_matrix[i, j] = gaussian_similarity(similarity_matrix[i], similarity_matrix[j])
#
#     return completed_matrix
#
#
# def fill_matrix(mat1, mat2):
#     mat1_copy = mat1.copy()
#     for i in range(mat1.shape[0]):
#         for j in range(mat1.shape[1]):
#             if mat1[i, j] == 0.0:
#                 mat1_copy[i, j] = mat2[i, j]
#     return mat1_copy
#
#
# # 主程序
# if __name__ == "__main__":
#     # 从本地文件读取疾病语义相似性数据
#     similarity_matrix = np.loadtxt(r'F:\daixie\New folder\data\dis_met_mat.csv', delimiter=',')
#     DMS = np.load(r'F:\daixie\New folder\DMS.npy')
#     print(similarity_matrix.shape)
#
#     # 补全相似性矩阵
#     completed_matrix = complete_similarity_matrix(similarity_matrix)
#
#     # 保存补全后的相似性矩阵到 Excel 文件
#     excel_file_path = r'F:\daixie\New folder\GS_DMS.xlsx'
#     workbook = openpyxl.Workbook()
#     sheet = workbook.active
#
#     for row in completed_matrix:
#         sheet.append(row.tolist())
#
#     workbook.save(excel_file_path)
#
#     print("Completed Similarity Matrix saved to Excel file:", excel_file_path)
#
#     dms_completed = fill_matrix(DMS, completed_matrix)
#     excel_file_path1 = r'F:\daixie\New folder\GS_DMS1.xlsx'
#     np.save(excel_file_path, dms_completed)
import numpy as np
import openpyxl
import pandas as pd


# 使用高斯核计算相似性
def gaussian_similarity(x, y, sigma=1.0):
    return np.exp(-np.linalg.norm(x - y) ** 2 / (2 * sigma ** 2))


def complete_similarity_matrix(similarity_matrix):
    num_diseases = similarity_matrix.shape[0]
    completed_matrix = np.zeros((num_diseases, num_diseases))

    # 使用高斯核相似性来补全相似性矩阵
    for i in range(num_diseases):
        for j in range(num_diseases):
            if i == j:
                completed_matrix[i, j] = 1.0  # 对角线上的相似性为1
            else:
                completed_matrix[i, j] = gaussian_similarity(similarity_matrix[i], similarity_matrix[j])

    return completed_matrix


def fill_matrix(mat1, mat2):
    mat1_copy = mat1.copy()
    for i in range(mat1.shape[0]):
        for j in range(mat1.shape[1]):
            if mat1[i, j] == 0.0:
                mat1_copy[i, j] = mat2[i, j]
    return mat1_copy


# 主程序
if __name__ == "__main__":
    # 从本地文件读取疾病语义相似性数据
    similarity_matrix = np.loadtxt(r'F:\daixie\New folder\data\dis_met_mat.csv', delimiter=',')
    DMS = np.load(r'F:\daixie\New folder\DMS.npy')
    print(similarity_matrix.shape)

    # 补全相似性矩阵
    completed_matrix = complete_similarity_matrix(similarity_matrix)

    # 保存补全后的相似性矩阵到 Excel 文件
    excel_file_path = r'F:\daixie\New folder\GS_DMS.xlsx'
    workbook = openpyxl.Workbook()
    sheet = workbook.active

    for row in completed_matrix:
        sheet.append(row.tolist())

    workbook.save(excel_file_path)

    print("Completed Similarity Matrix saved to Excel file:", excel_file_path)

    dms_completed = fill_matrix(DMS, completed_matrix)
    dms_excel_file_path = r'F:\daixie\New folder\GS_DMS1.xlsx'

    # 将NumPy数组保存为Excel文件
    df = pd.DataFrame(dms_completed)
    df.to_excel(dms_excel_file_path, index=False, header=False)

    print("Completed DMS saved to Excel file:", dms_excel_file_path)