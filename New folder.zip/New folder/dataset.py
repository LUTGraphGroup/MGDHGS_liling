import sys
#sys.path.append(r"F:\疾病预测\shiyan\a\pytorch_geometric-master")
#sys.path.append(r"F:\疾病预测\shiyan\a\pytorch_geometric-master")

import pandas as pd
import numpy as np
import torch
from torch_geometric.data import HeteroData
import torch_geometric.transforms as T


from utils import KfoldLinkSplit
#可重复性，固定seed
from torch_geometric import seed_everything

seed_everything(202)
torch.manual_seed(202)
np.random.seed(202)

# 检查是否能使用gpu，如果能使用device=cuda
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

#添加文件夹
import os
folder_list = ['loss','model','roc']
for folder_name in folder_list:
    if (not os.path.exists(folder_name)):
        os.makedirs(folder_name)

#读取特征和关联矩阵
df_diease = pd.read_csv('data/dieaseSmi2.csv',header=None)
df_gene = pd.read_csv('data/geneSim2.csv',header=None)
df_met = pd.read_csv('data/metSim2.csv',header=None)

df_associations_dis_met = pd.read_csv('data/dis_met_mat.csv',header=None)
df_associations_met_gene = pd.read_csv('data/met_gene_mat.csv',header=None)
df_associations_dis_gene = pd.read_csv('data/dis_gene_mat.csv',header=None)

#读取表格数据，转换成numpy，并且标准化
def standarize(df):
    df = df.values
    df_max = df.max()
    df_min = df.min()
    return (df - df_min)/(df_max - df_min)


data = HeteroData()
# 添加节点index
data["diease"].node_id = torch.arange(len(df_diease))
data["gene"].node_id = torch.arange(len(df_gene))
data["met"].node_id = torch.arange(len(df_met))
# 添加节点数据
data["diease"].x = torch.Tensor(standarize(df_diease))
data["gene"].x = torch.Tensor(standarize(df_gene))
data["met"].x = torch.Tensor(standarize(df_met))
# 添加边
associations_indices_dis_met = np.where(df_associations_dis_met.values == 1)
associations_indices_met_gene = np.where(df_associations_met_gene.values == 1)
associations_indices_dis_gene = np.where(df_associations_dis_gene.values == 1)
associations_indices_dis = np.where(df_diease.values > 0 )
associations_indices_gene = np.where(df_gene.values > 0)
associations_indices_met = np.where(df_met.values > 0)
data["diease", "association1", "met"].edge_index = torch.Tensor(associations_indices_dis_met).long()
data["met", "association2", "gene"].edge_index = torch.Tensor(associations_indices_met_gene).long()
data["diease", "association3", "gene"].edge_index = torch.Tensor(associations_indices_dis_gene).long()
data["diease", "association4", "diease"].edge_index = torch.Tensor(associations_indices_dis).long()
data["gene", "association5", "gene"].edge_index = torch.Tensor(associations_indices_gene).long()
data["met", "association6", "met"].edge_index = torch.Tensor(associations_indices_gene).long()
# 使用ToUndirected添加反向的边
data = T.ToUndirected()(data)
print(data)


# 划分数据集,5折
# 随机打乱序号
num_of_links = data["diease", "association1", "met"].edge_index.shape[1]
perm = torch.randperm(num_of_links).tolist()
# 确定折数
num_of_fold = 5
fold_size = int(num_of_links / num_of_fold)
train_list = []
val_list = []

for i in range(num_of_fold):
    transform = KfoldLinkSplit(
        num_val=0.2,  # 训练集20%
        num_test=0.0,
        disjoint_train_ratio=0.3,
        neg_sampling_ratio=1.0,  # 采样负样本边
        add_negative_train_samples=False,
        edge_types=("diease", "association1", "met"),
        rev_edge_types=("met", "rev_association1", "diease"),
        perm=perm  # 固定每一次随机的顺序
    )
    train_data, val_data, _ = transform(data)
    train_list.append(train_data)
    val_list.append(val_data)
    # fold向右滑动一步，依次轮换后20%
    perm_tmp = perm.copy()
    perm = perm_tmp[(num_of_fold - 1) * fold_size:] + perm_tmp[:(num_of_fold - 1) * fold_size]